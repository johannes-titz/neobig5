library(testthat)
library(star)

test_check("star")
