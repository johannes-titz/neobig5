#https://stackoverflow.com/questions/50571325/r-cran-check-fail-when-using-parallel-functions

chk <- Sys.getenv("_R_CHECK_LIMIT_CORES_", "")

if (nzchar(chk) && chk == "TRUE") {
  # use 2 cores in CRAN/Travis/AppVeyor
  num_workers <- 2L
} else {
  # use all cores in devtools::test()
  num_workers <- parallel::detectCores()
}

# start of tests
data("neo_pi_r_eugene")
data(big5, package = "star")

sim100 <- sim_parameters(1e2, mc_cores = 20)
sim10 <- sim_parameters(10, mc_cores = 20)
sim2 <- sim_parameters(2, mc_cores = 20)
# library(future)
# plan(multicore, workers = round(availableCores() * 0.8))
few_values <- na.omit(big5[, c("O88", "O3")])
names(few_values) <- c("x", "y")
few_values_reversed <- few_values
names(few_values_reversed) <- names(few_values)[2:1]

data_0var <- na.omit(big5[, c("C15", "C5")])
names(data_0var) <- c("x", "y")
data_0var$y[data_0var$x == 1] <- 5
data_0var2 <- data_0var
data_0var2$y[data_0var2$x == 2] <- 4

test_that("filter_scale_points works", {
  expect_equal(filter_scale_points(few_values, sim_parameters(n_min = 9))$n_min_violated, 1)
  expect_equal(filter_scale_points(few_values, sim_parameters(n_min = 8))$n_min_violated, 0)
  expect_equal(filter_scale_points(few_values, sim_parameters(n_min = 38))$n_min_violated, 2)
  expect_equal(filter_scale_points(data_0var, sim_parameters())$var0, 1)
  expect_equal(filter_scale_points(data_0var2, sim_parameters())$var0, 2)
})

test_that("monoreg_bootstrap_p works", {
  expect_lt(monoreg_bootstrap_p(neo_pi_r_eugene$A144,
                                neo_pi_r_eugene$A4, sim100)$result$p, 0.01)
  expect_gt(monoreg_bootstrap_p(neo_pi_r_eugene$A144,
                                neo_pi_r_eugene$C35, sim100)$result$p, 0.01)
  }
)

test_that("own monoreg function works", {
  expect_equal(round(monoreg(neo_pi_r_eugene$A144, neo_pi_r_eugene$A4)$yf, 4),
               c(3.2750, 3.4010, 3.4010, 3.4010, 3.4010))
})

test_that("items against dimension works", {
  expect_equal(
    round(test_items_against_dimension(c("A144"),
                                       data = neo_pi_r_eugene,
                                       sim2)$aggregated_deviance[1],
          4),
    133.0564)
  }
)

sim3 <- sim_parameters(2, mc_cores = 20, weight_function = "weight_prec")
test_that("items against dimension works with kalish weighting function", {
  expect_equal(
    round(test_items_against_dimension(c("A144"),
                                       data = neo_pi_r_eugene,
                                       sim3)$aggregated_deviance[1],
          4),
    164.375)
}
)

# d <- neo_pi_r_eugene[, c("A144", "A4")]
# names(d) <- c("x", "y")
# deviances <- bootstrap_deviances_model(d, sim100)
# deviances_param <- bootstrap_deviances_parametric(d, sim100)
# test_that("bootstrap parametric is similar to non-parametric", {
#
# })

factor_a_vars <- grep("A[0-9]+$", names(neo_pi_r_eugene), value = T)
facet_modesty_vars <- paste0("A", seq(4, 214, 30))

test_that("neo-pi-r severe violations are detected", {
  expect_lte(test_specific_items(neo_pi_r_eugene, "A144", "A4", sim100)$p, 0.01)
  expect_equal(test_specific_items(neo_pi_r_eugene, "A144", facet_modesty_vars, sim10)$p_aggregated[1], 0)
  expect_equal(test_specific_items(neo_pi_r_eugene, "A144", factor_a_vars, sim10)$p_aggregated[1], 0)
})

test_that("neo-pi-r minor violations are not producing false alarms", {
  expect_gt(test_specific_items(neo_pi_r_eugene, "A144", "C35", sim100)$p, 0.1)
  expect_gt(test_specific_items(neo_pi_r_eugene, "C35", paste0("A", seq(4, 214, 30)), sim100)$p[1], 0.1)
})

d <- neo_pi_r_eugene[, c("A144", "A4")]
d <- na.omit(d)
monoreg_res <- monoreg(d$A144, d$A4, "weight_n")
names(d) <- c("x", "y")

# test_that("calc_r_es and calc_r2 give same values", {
#   expect_equal(1 - calc_r_es(monoreg_res)[[1]]^2, calc_r2_error(monoreg_res)[[1]])
#   }
# )

monoreg <- monoreg(d$x, d$y)
y_list <- split(d$y, d$x)
shift_y <- shift_to_null2(y_list, monoreg)
shift_monoreg <- monoreg3(shift_y)
diff <- sum(shift_monoreg$yf - shift_monoreg$y)

test_that("shifting results in monotonic model", {
  expect_equal(all.equal(diff, 0), T)
})

# shifting results in r_2_error of 0
# calc_r2_error(shift_monoreg)

# p <- plot_it(neo_pi_r_eugene[, c("A144", "A4")])

#
df <- neo_pi_r_eugene[, c("A164", "A4")]
names(df) <- c("x", "y")
df <- na.omit(df)
test_that("filter scale points when n = 1", {
  expect_equal(filter_scale_points(df, sim_parameters())$var0, 1)
})

data(pair)
test_that("mean_by works", {
  expect_equal(mean_by(pair$y, tabulate(pair$x)), as.numeric(by(pair$y, pair$x, mean)))
})

# delay example

# mono_av1 <- c(0.3759, 0.4850, 0.5898, 0.6265, 0.3353, 0.4186, 0.4806, 0.4850)
# mono_av2 <- c(0.3150, 0.4358, 0.5167, 0.5318, 0.2856, 0.3150, 0.3277, 0.3227)
# index <- order(mono_av1)
# plot(mono_av1[index], mono_av2[index], type = "b")

# data(delay)
# stats <- delay %>%
#   group_by(structure, block, delay) %>%
#   summarize(mean_pc = mean(pc), n = n(), var_pc = var(pc))
# plot(fdrtool::monoreg(stats$mean_pc[1:8], w = stats$n[1:8] / stats$var_pc[1:8]))

test_that("item against dimension produces correct deviance",{
  expect_equal(test_item_against_dimension("E17", big5, sim_parameters(n_bootstrap_samples = 2))$aggregated_deviance[1],
               558.27642)
})

# # must always give 85.xxx as deviance, but does not
# must produce significant result; p-value smaller than 0.05/240?
res <- test_items_against_dimension("A164", big5,
                                    sim_parameters(n_bootstrap_samples = 1e3,
                                                   mc_cores = future::availableCores()-1))
test_that("parallel random number generation produces correct p-value", {
  expect_lte(res$p_aggregated[1], 0.05/240)
})

# # must give 15.43858
# test_specific_items(big5, "A164", "A84", sim_parameters())
