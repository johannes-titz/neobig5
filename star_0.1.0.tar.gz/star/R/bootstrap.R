#' Calculates p values for monotonic regression via bootstrapping
#'
#' Note that missing values (NA) are removed. Also, 0 variance scale points are
#' removed and scale pionts that have few values.
#'
#' @param x x value for monotonic regression
#' @param y y value for monotonic regression
#' @param sim_parameters object of simulation parameters
#'
#' @return list with a two values:
#'   result: (data frame) containing the most important results
#'   deviances_model: vector of bootstrapped deviance values
#' @export
#' @importFrom stats na.omit
monoreg_bootstrap_p <- function(x, y, sim_parameters) {
  d <- data.frame(x = x, y = y)
  names(d) <- c("x", "y")
  d <- na.omit(d)
  d <- d[order(d$x), ]
  # check scale points for problems
  filtered_scale_points <- filter_scale_points(d, sim_parameters)
  d <- filtered_scale_points$d
  # make y list
  y_list <- split(d$y, d$x)
  # monoreg for actual data
  monoreg_data <- monoreg3(y_list, sim_parameters$weight_function)
  deviance_data <- sim_parameters$stat_function(monoreg_data)
  #r2_error <- calc_r2_error(monoreg_data)[[1]]

  partial_deviances <- as.numeric(deviance_data$partial_deviances)
  names(partial_deviances) <- filtered_scale_points$keep
  # bootstrap
  deviances_model <- bootstrap_deviances_model(y_list, sim_parameters)
  p <- calc_p(deviances_model, deviance_data["statistic"])
  return(list(result = data.frame(
    p,
    deviance_data = deviance_data$statistic,
    n = nrow(d),
    partial_deviances = t(partial_deviances),
    n_min_violated = filtered_scale_points$n_min_violated,
    var0 = filtered_scale_points$var0),
    #r2_error = r2_error),
    deviances_model = deviances_model))
}

#' Filter scale points
#'
#' @inheritParams monoreg_bootstrap_p
#' @param d data frame with x and y
#' @return list with filtered data frame d and n_min_violated, var0 values, as well as
#'   kept x scale points (keep)
#' @importFrom dplyr summarize n group_by filter
#' @noRd
#' @importFrom stats var
filter_scale_points <- function(d, sim_parameters) {
  d2 <- dplyr::group_by(d, x)
  keep_scale_points <-  dplyr::summarize(d2, var_y = var(y), n = dplyr::n())
  # NA can actually happen if n = 1
  # var filtering does not make too much sense as it can happen that many persons
  # answer the same, e.g. see A144 versus A129
  var0 <- sum(keep_scale_points$var_y == 0 | is.na(keep_scale_points$var_y))
  n_min_violated <- sum(keep_scale_points$n < sim_parameters$n_min)

  keep_scale_points <- dplyr::filter(keep_scale_points,
                                     n >= sim_parameters$n_min)

  d <- dplyr::filter(d, x %in% keep_scale_points$x)

  return(list(d = d, n_min_violated = n_min_violated, var0 = var0,
              keep = keep_scale_points$x))
}

#' Bootstrap monoreg deviances_model
#'
#' @param y_list list of y values grouped by x
#' @inheritParams monoreg_bootstrap_p
#' @return vector of deviance values
#' @noRd
bootstrap_deviances_model <- function(y_list, sim_parameters) {
  #n <- tabulate(d$x)
  deviances_model <- .Internal(unlist(
    #pbmcapply::pbmclapply(
    #parallel::mclapply(
      lapply(
      1:sim_parameters$n_bootstrap_samples,
      function(x) bootstrap_one_deviance(y_list, sim_parameters)#,
      #mc.cores = sim_parameters$mc_cores
    )
  , FALSE, FALSE))
  return(as.numeric(deviances_model))
}

#' shifts average y_list values to monotonic model
#'
#' @inheritParams filter_scale_points
#' @param monoreg_res object of class monoreg
#' @return data frame containing x and shifted y values named x,y
#' @noRd
shift_to_null2 <- function(y_list, monoreg_res) {
  y_list <- Map(function(y, yf, y_mean) y - (y_mean - yf),
                y_list, monoreg_res$yf, monoreg_res$y)
  return(y_list)
}

#' Draws one bootstrap sample and calculates deviance
#'
#' @inheritParams bootstrap_deviances_model
#' @return deviance for one bootstrap sample
#' @noRd
bootstrap_one_deviance <- function(y_list, sim_parameters) {
  # first bootstrap step
  y_boot1 <- sample_nonparametric6(y_list)
  monoreg_boot1 <- monoreg3(y_boot1, sim_parameters$weight_function)

  # shift distribution to monotonic model
  y_shifted <- shift_to_null2(y_boot1, monoreg_boot1)

  # second bootstrap step
  y_boot2 <- sample_nonparametric6(y_shifted)

  monoreg_boot2 <- monoreg3(y_boot2, sim_parameters$weight_function)
  deviance <- sim_parameters$stat_function(monoreg_boot2)["statistic"]
  return(deviance)
}

#' Sampling function
#'
#' @param y list of y values grouped by x
#' @return list of bootstraped y values grouped by x
#' @importFrom dqrng dqsample.int
sample_nonparametric6 <- function(y) {
  y <- lapply(y, function(y) y[dqrng::dqsample.int(length(y), replace = TRUE)])
  y
}

sample_parametric <- function(d) {
  d <- d %>%
    group_by(x) %>%
    summarize(mean_y = mean(y), sd_y = sd(y), n = n())
  d_boot <- Map(function(mean_y, sd_y, n, x)
    cbind(y = rnorm(n, mean_y, sd_y), x = x),
    d$mean_y, d$sd_y, d$n, d$x)
  d_boot
}

#' calculate p-value from bootstrapped deviances_model
#'
#' @param deviances_model: vector of deviance values from bootstrap samples
#' @param deviance_data empirically found deviance value
#' @return p-value
#' @noRd
calc_p <- function(deviances_model, deviance_data) {
  p <- mean(deviances_model >= deviance_data)
  return(p)
}

#' Calculate residual deviance for monoreg
#'
#' @inheritParams shift_to_null
#' @return list named deviance with two values: deviance contains the residual
#'   deviance, partial_deviances_model contains deviances_model for each x-value
#'   (useful for exploratory data analysis)
#' @noRd
calc_deviance <- function(monoreg_result) {
  partial_deviances_model <-
    monoreg_result$w * (monoreg_result$y - monoreg_result$yf)^2
  names(partial_deviances_model) <- monoreg_result$x
  deviance <- list(statistic = sum(partial_deviances_model),
                   partial_deviances = t(partial_deviances_model))
  return(deviance)
}

#' Adapted version of fdrtool::monoreg
#'
#' This is the fastest way to calculate means by group, which are then fed into
#' fdrtool::monoreg. y_list must be ordered (vectors in the list are for x=1, x=2 ...).
#'
#' @inheritParams bootstrap_deviances_model
#' @param weight_function function to use for weighting
#' @return monoreg object
#' @export
monoreg3 <- function(y_list, weight_function = c("weight_n", "weight_prec")) {
  y_mean <- sapply(y_list, mean)
  w <- do.call(weight_function[1], args = list(y_list))
  n <- sapply(y_list, length)
  monoreg <- fdrtool::monoreg(y_mean, NULL, w)
  monoreg$n <- n
  return(monoreg)
}

#' weight by n
#' @inheritParams  monoreg3
#' @return weights vector
#' @noRd
weight_n <- function(y_list) {
  sapply(y_list, length)
}

#' weight by precision
#'
#' @inheritParams  monoreg3
#' @return weights vector
#' @noRd
weight_prec <- function(y_list) {
  var <- sapply(y_list, var)
  n <- sapply(y_list, length)
  w <- n / var
  w <- ifelse(is.infinite(w), 0, w)
  w
}

#' Calculate r_alerting for monotonic regression
#'
#' @return list with two values: statistic and partial_deviances (NA in this case).
#' @export
#' @importFrom stats cor sd
calc_r_alerting <- function(monoreg_result) {
  if (stats::sd(monoreg_result$yf) != 0 & stats::sd(monoreg_result$y) != 0) {
    cor <- stats::cor(monoreg_result$y, monoreg_result$yf)
  } else {
    cor <- NA
  }
  list(statistic = cor, partial_deviances = NA)
}
