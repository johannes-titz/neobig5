one_power_sample <- function(obj) {
  param <- sim_parameters(n_bootstrap_samples = obj$bootstrap_samples_monoreg)
  boot_sample <- obj$data[sample(nrow(obj$data), obj$sample_size), ]
  res <- test_specific_items(boot_sample, obj$i, obj$j, param)
  res$p_aggregated[1]
}

#' @export
calculate_power <- function(obj) {
  p_aggregated <- sapply(1:obj$bootstrap_samples_power, function(x) one_power_sample(obj))
  obj$power <- mean(p_aggregated <= obj$alpha)
  obj
}

#' @export
create_object <- function(data, i, j, sample_size, bootstrap_samples_power,
                          bootstrap_samples_monoreg, alpha) {
  obj <- list(data = data, i = i, j = j, sample_size = sample_size,
              bootstrap_samples_power = bootstrap_samples_power,
              bootstrap_samples_monoreg = bootstrap_samples_monoreg, alpha = alpha)
  obj
}

#' @export
#' @import dplyr
extract_sig_items <- function(data, alpha) {
  left_items <- data %>% filter(p_aggregated <= alpha) %>%
    select(i) %>%
    unique() %>%
    unlist()
}

#' @export
create_neo_pi_r_items <- function(){
  neo_pi_r_items <- expand.grid(dimension = c("N", "E", "O", "A", "C"), facet = 1:6,
                                facet_item = 1:8)
  neo_pi_r_items <- neo_pi_r_items %>%
    dplyr::mutate(item_number = 1:nrow(neo_pi_r_items),
           item_char = paste(dimension, item_number, sep = ""))
  return(neo_pi_r_items)
}

#' @export
create_ipip_neo_items <- function(){
  neo_pi_r_items <- expand.grid(dimension = c("N", "E", "O", "A", "C"), facet = 1:6,
                                facet_item = 1:4)
  neo_pi_r_items <- neo_pi_r_items %>%
    dplyr::mutate(item_number = 1:nrow(neo_pi_r_items),
           item_char = paste(dimension, item_number, sep = ""))
  return(neo_pi_r_items)
}

# plots mean + 99% CI for second column of 2-column data frame,
# grouped by column 1
#' @importFrom dplyr summarize_all
#' @import ggplot2
#' @export
plot_it <- function(d, min_n = 8, with_n = T) {
  d <- na.omit(d)
  orig_names <- names(d)
  names(d) <- c("uv", "av")
  save <- d %>% group_by(uv) %>%
    summarize_all(.funs = list(mean = function(x) mean(x),
                               se = function(x) sd(x)/length(x),
                               n = function(x) length(x)))
  save <- dplyr::mutate(save,
                 ymin = mean - se * qnorm(.99),
                 ymax = mean + se * qnorm(.99), n = n)
  save <- save %>% filter(n >= min_n)
  monoreg <- fdrtool::monoreg(d$uv, d$av)
  save$yf <- monoreg$yf
  deviance_data <- calc_deviance(monoreg)[[1]]
  avg_deviation <- sqrt(deviance_data / sum(save$n))
  r2 <- calc_r_alerting(monoreg)
  #pdf(paste("plots/", paste(orig_names, collapse = ""), ".pdf", sep =""),
  #    width = 10, height = 6)
  p <- ggplot(save, aes(uv, y = mean, ymin = ymin, ymax = ymax)) +
    geom_pointrange(shape = 20) +
    geom_point(aes(uv, y = yf), shape = 1) +
    scale_x_continuous(orig_names[1], breaks = 1:5, limits = c(1, 5.5)) +
    scale_y_continuous(orig_names[2])  + theme_bw() + theme_classic()
  #annotate("text", 4, max(save$mean), label = paste("dev =", round(avg_deviation, 2)))
  if (with_n) {
    return(p +
             annotate("text", x=save$uv+0.05, hjust = 0, y=save$mean,
                      label = as.character(save$n)))
  } else {
    return(p)
  }
  #dev.off()
}

#' Test item against dimension
#'
#' Tests one item against the whole dimension in data set, where names are in the form
#' "Dimension.Itemnumber", e.g. N1, E2, O3, ... not exported, since the vectorized
#' version also works in this case
#'
#' @param item name of item as character
#' @param data
#' @param sim_parameters object of type sim_parameters
#' @return
#' @noRd
test_item_against_dimension <- function(item, data, sim_parameters) {
  dimension <- substr(item, 1, 1)
  items_of_dimension <- names(data)
  items_of_dimension <- items_of_dimension[grepl(dimension, items_of_dimension)]
  items_of_dimension <- items_of_dimension[!grepl(paste0("^", item, "$"),
                                                  items_of_dimension)]
  res <- test_specific_items(
    data,
    item,
    items_of_dimension,
    sim_parameters
  )
  res
}

#' Test items against dimension
#'
#' Wrapper for test_item_against_dimension to test against multiple items.
#'
#' @inheritParams  test_item_against_dimension
#' @param items names of items as character
#' @return data frame of most important results
#' @export
test_items_against_dimension <- function(items, data, sim_parameters) {
  res <- pbapply::pblapply(items, function(x) {
    test_item_against_dimension(x, data, sim_parameters)
  })
  #res <- parallel::mclapply(items, test_item_against_dimension, data, sim_parameters,
  #                          mc.cores = availableCores()-1)
  #res <- furrr::future_map(items, test_item_against_dimension, data, sim_parameters,
  #                         .options = furrr::furrr_options(seed = TRUE))
  plyr::ldply(res, "data.frame")
}

#' Test all item pairs in data frame
#'
#' @inheritParams
#' @return data frame of most important results, each row is one item comparison pair
test_all_item_pairs <- function(d, sim_parameters) {
  # make all relevant item combinations
  combs <- gtools::permutations(
    length(names(d)),
    r = 2,
    names(d),
    repeats.allowed = FALSE
  )
  res <- Map(function(x, y) monoreg_bootstrap_p(d[, x], d[, y], sim_parameters),
             combs[,1],
             combs[,2])
  # extract only important summary information, not the deviances_model
  res_df <- lapply(res, function(x) x[[1]])
  res_df <- plyr::ldply(res_df, "data.frame")
  return(res_df)
}

#' Test specific item pairs in data frame
#'
#' @inheritParams
#' @return data frame of most important results, each row is one item comparison pair
#' @param i character vector of column names to test, this cannot be a factor!
#' @param j character vector of column names to test, this cannot be a factor!
#' @export
#' @importFrom furrr furrr_options future_map2
test_specific_items <- function(d, i, j, sim_parameters) {
  # vectorize if i is a single character
  if (length(i) == 1) {
    j <- j[!(j %in% i)]
    i <- rep(i, length(j))
  }
  dqrng::dqRNGkind("Threefry")

  res <- parallel::mcmapply(
  #res <- Map(
  #res <- furrr::future_map2(
    function(x, y) {
      dqrng::dqset.seed(NULL, as.numeric(as.factor(y)))
      monoreg_bootstrap_p(d[, x], d[, y], sim_parameters)},
    i,
    j,
    #function(x, y) {
    #  p()
    #  monoreg_bootstrap_p(d[, x], d[, y], sim_parameters)
    #},
    #.options = furrr::furrr_options(seed = TRUE))
  #)
    mc.cores = sim_parameters$mc_cores,
    SIMPLIFY = FALSE
  )

  aggregated_deviance <- sum(sapply(res, function(x) x[[1]]$deviance_data))
  aggregated_bootstrap_deviances_model <-
    rowSums(sapply(res, function(x) x$deviances_model))
  p_aggregated <- mean(aggregated_bootstrap_deviances_model >= aggregated_deviance)
  res_df <- lapply(res, function(x) x[[1]])
  res_df <- plyr::ldply(res_df, "data.frame")
  res_deviances <- lapply(res, function(x) x[[2]])
  return(cbind(i, j, res_df, p_aggregated, aggregated_deviance))
}

#' Create simulation parameters
#'
#' @param n_bootstrap_samples number of bootstrap samples, default 1e3
#' @param mc_cores number of cores to use for bootstrapping, default 1
#' @param parametric logical, should parametric bootstrapping be used, default FALSE
#' @param weight_function how should means for scale points be weighted in monoreg,
#'   either "weight_n" or "weight_prec"
#' @param n_min minimum number of participants for each scale point
#' @return object of type sim_parameters
#' @export
sim_parameters <- function(n_bootstrap_samples = 1e3, mc_cores = 1,
                           parametric = F,
                           weight_function = c("weight_n", "weight_prec"),
                           n_min = 5,
                           stat_function = calc_deviance,
                           sampling_function = sample_nonparametric6) {
  if (n_bootstrap_samples <= 1) stop("n_bootstrap_samples must be larger than 1")
  structure(as.list(environment(), "sim_parameters"))
}

