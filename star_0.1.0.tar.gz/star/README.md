
<!-- README.md is generated from README.Rmd. Please edit that file -->

# todo

-   simplify interface functions
-   test out ordinal versus interval
-   test weighting functions
-   test r_alerting
-   fix r alerting for 0-variance IV

clean up everything

## r alerting

does not work when the contrasts are all the same! lambda_j \* mean_j,
when mean_j is a constant and lambda_j are centered, the mean will be 0.
so qs_contrast becomes 0. Deviance can still be large or small! Maybe,
mean absolute deviation or sqrt of deviance makes more sense?

# star

<!-- badges: start -->
<!-- badges: end -->

The goal of star is to provide state trace analysis in R for
non-experimental data. If you have experimental data, use the staCMR
package.

## Installation

You can install the released version of star from
[CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("star")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(star)
library(dplyr)
## basic example code
```

## Use different bootstrap statistics

Default is deviance

``` r
params <- sim_parameters(mc_cores = 20)
data("neo_pi_r_eugene")
test_specific_items(neo_pi_r_eugene, "A144", "A4", params)
#>      i  j  .id     p deviance_data   n partial_deviances.1 partial_deviances.2
#> 1 A144 A4 A144 0.005      17.51671 838                   0            1.119057
#>   partial_deviances.3 partial_deviances.4 partial_deviances.5 n_min_violated
#> 1           0.1247617          0.04213709            16.23075              0
#>   var0  r2_error p_aggregated aggregated_deviance
#> 1    0 0.9993754        0.005            17.51671
```

R² of monotonic model is an interesting alternative, but produces larger
p-values.

``` r
params <- sim_parameters(mc_cores = 20, stat_function = calc_r2_error)
res <- test_specific_items(neo_pi_r_eugene, "A144", "A4", params)
res
#>      i  j  .id     p deviance_data   n partial_deviances n_min_violated var0
#> 1 A144 A4 A144 0.216     0.9993754 838                NA              0    0
#>    r2_error p_aggregated aggregated_deviance
#> 1 0.9993754        0.216           0.9993754
```

This is also the case for all other modesty items against A144. Not sure
what this means. There seem to be certain cases where it is very likely
that the monotonic model will not fit at all. r_effect_size is affected
by the general variance of the data. Even if the monotonic model fits
perfectly, r_effect_size can be large. It is still a bit starnge that it
produces a different p-value, but maybe the distribution is not very
well defined when error variance is large?

r_alerting could still be useful here as we expect it to be 1, even when
error variance is substantial. But r_alerting is not weighted by sample
size. Still, bootstrapping should work. But you cannot calculate
r_alerting when monotonic model is a constant value. This is where
deviance is clearly superior.

Show with r_alerting, p-value looks good.

``` r
params <- sim_parameters(mc_cores = 20, stat_function = calc_r_alerting)
res <- monoreg_bootstrap_p(neo_pi_r_eugene$A144, neo_pi_r_eugene$A4, params)
hist(unlist(res[[2]]))
```

<img src="man/figures/README-unnamed-chunk-4-1.png" width="100%" />

``` r
m1 <- monoreg(neo_pi_r_eugene$A144, neo_pi_r_eugene$A4)
mean(calc_r_alerting(m1)$statistic >= unlist(res[[2]]), na.rm = T)
#> [1] 0.09793254
```

## Interval versus Ordinal

At first sight looks ok, but A154 produces p-value of .15 for ordinal.
Not really clear why.

``` r
params <- sim_parameters(mc_cores = 20)
facet_modesty_vars <- paste0("A", seq(4, 214, 30))
interval <- test_specific_items(neo_pi_r_eugene, "A144", facet_modesty_vars, params)

# make ranks for a factor, except a144?
d2 <- neo_pi_r_eugene %>% mutate_all(rank, na.last = "keep")
ordinal <- test_specific_items(d2, "A144", facet_modesty_vars, params)
interval
#>      i    j  .id     p deviance_data   n partial_deviances.1
#> 1 A144   A4 A144 0.000     17.516706 838           0.0000000
#> 2 A144  A34 A144 0.004     15.950627 840           0.0000000
#> 3 A144  A64 A144 0.002     13.282590 837           0.2026456
#> 4 A144  A94 A144 0.005      8.322524 843           0.2223389
#> 5 A144 A124 A144 0.007      9.275265 840           2.4526077
#> 6 A144 A154 A144 0.040      7.968940 840           0.0000000
#> 7 A144 A184 A144 0.066      5.565086 836           1.4464513
#> 8 A144 A214 A144 0.002     14.169380 838           1.3702548
#>   partial_deviances.2 partial_deviances.3 partial_deviances.4
#> 1           1.1190571        0.1247616649          0.04213709
#> 2           2.6711410        0.0022969828          0.76927503
#> 3           2.2929923        0.2204518600          2.95136668
#> 4           2.2563157        0.1605564008          0.93008051
#> 5           1.6621723        0.2590491829          1.39641017
#> 6           1.3456216        0.0002265219          0.31969058
#> 7           0.9160181        0.0534297766          1.06920783
#> 8           3.0421042        0.0202402732          3.02910999
#>   partial_deviances.5 n_min_violated var0  r2_error p_aggregated
#> 1           16.230750              0    0 0.9993754            0
#> 2           12.507914              0    0 0.9994765            0
#> 3            7.615134              0    0 1.0000000            0
#> 4            4.753233              0    0 1.0000000            0
#> 5            3.505026              0    0 1.0000000            0
#> 6            6.303402              0    0 0.9997149            0
#> 7            2.079979              0    0 1.0000000            0
#> 8            6.707670              0    0 1.0000000            0
#>   aggregated_deviance
#> 1            92.05112
#> 2            92.05112
#> 3            92.05112
#> 4            92.05112
#> 5            92.05112
#> 6            92.05112
#> 7            92.05112
#> 8            92.05112
ordinal
#>      i    j  .id     p deviance_data   n partial_deviances.20.5
#> 1 A144   A4 A144 0.008      598238.3 838                   0.00
#> 2 A144  A34 A144 0.001      720195.1 840                   0.00
#> 3 A144  A64 A144 0.006      590454.0 837               14436.32
#> 4 A144  A94 A144 0.019      445826.9 843               32851.08
#> 5 A144 A124 A144 0.014      505157.7 840              200903.63
#> 6 A144 A154 A144 0.143      201802.5 840                   0.00
#> 7 A144 A184 A144 0.055      330439.1 836              144210.90
#> 8 A144 A214 A144 0.002      711179.0 838              110672.80
#>   partial_deviances.218.5 partial_deviances.512.5 partial_deviances.721
#> 1                37661.85               1759.5523              74.01316
#> 2               182214.31              14802.0356           28392.98618
#> 3               134984.78                576.6824          136176.54066
#> 4               150844.58              40814.2711           52567.12428
#> 5                88825.47              55335.8755           49409.16488
#> 6                67096.13              24496.5554            2484.24741
#> 7                66874.58              48332.7914           61525.61125
#> 8               199404.61              18119.9175          200222.64934
#>   partial_deviances.829 n_min_violated var0  r2_error p_aggregated
#> 1            558742.865              0    0 0.9994884            0
#> 2            494785.816              0    0 0.9999927            0
#> 3            304279.671              0    0 1.0000000            0
#> 4            168749.849              0    0 1.0000000            0
#> 5            110683.603              0    0 1.0000000            0
#> 6            107725.598              0    0 0.9998632            0
#> 7              9495.194              0    0 1.0000000            0
#> 8            182759.046              0    0 1.0000000            0
#>   aggregated_deviance
#> 1             4103293
#> 2             4103293
#> 3             4103293
#> 4             4103293
#> 5             4103293
#> 6             4103293
#> 7             4103293
#> 8             4103293
```

What about all other items that were significant? mutate_all should be
OK here, even when a variable is used for X

``` r
params <- sim_parameters(mc_cores = 20)
d2 <- neo_pi_r_eugene %>% mutate_all(rank, na.last = "keep")
tests <- test_items_against_dimension(
  c("A129", "A144", "A164", "A99", "C35", "E17", "E2", "N31", "N96"),
  d2,
  params
)
tests %>% group_by(i) %>% slice(1) %>% select(i, p_aggregated)
#> # A tibble: 9 × 2
#> # Groups:   i [9]
#>   i     p_aggregated
#>   <chr>        <dbl>
#> 1 A129             0
#> 2 A144             0
#> 3 A164             0
#> 4 A99              0
#> 5 C35              0
#> 6 E17              0
#> 7 E2               0
#> 8 N31              0
#> 9 N96              0
```

## Weighting function

p-values seem to be smaller with n-weighting, larger with
N/SE^2-weighting. But at least for modesty the aggregated p-value is
still very small. A144 against A154 has a larger p-value than
previously.

``` r
params <- sim_parameters(mc_cores = 20, weight_function = "weight_prec")
weight_prec <- test_specific_items(neo_pi_r_eugene, "A144", facet_modesty_vars, params)
weight_prec
#>      i    j  .id     p deviance_data   n partial_deviances.1
#> 1 A144   A4 A144 0.021     10.726001 838           0.0000000
#> 2 A144  A34 A144 0.001     15.859101 840           0.0000000
#> 3 A144  A64 A144 0.016     11.115070 837           0.1089775
#> 4 A144  A94 A144 0.000     12.685541 843           0.2494221
#> 5 A144 A124 A144 0.000     11.968346 840           3.6003620
#> 6 A144 A154 A144 0.075      5.733919 840           0.0000000
#> 7 A144 A184 A144 0.033      6.743854 836           1.7239332
#> 8 A144 A214 A144 0.002     13.791143 838           1.2089112
#>   partial_deviances.2 partial_deviances.3 partial_deviances.4
#> 1           0.6775991          0.02622472           0.1117772
#> 2           3.2442520          0.29817694           2.3514413
#> 3           1.9401730          0.08916273           3.5285320
#> 4           4.0025347          1.18047669           2.8850954
#> 5           1.9821506          0.91917869           2.4396842
#> 6           1.2720110          0.12156843           0.7463006
#> 7           1.4166974          0.23387812           2.0015522
#> 8           3.4034780          0.18994179           4.6252906
#>   partial_deviances.5 n_min_violated var0  r2_error p_aggregated
#> 1            9.910400              0    0 0.9991381            0
#> 2            9.965231              0    0 0.9978994            0
#> 3            5.448224              0    0 0.9998070            0
#> 4            4.368013              0    0 0.9992412            0
#> 5            3.026971              0    0 0.9996786            0
#> 6            3.594039              0    0 0.9992340            0
#> 7            1.367793              0    0 0.9999412            0
#> 8            4.363521              0    0 0.9997534            0
#>   aggregated_deviance
#> 1            88.62298
#> 2            88.62298
#> 3            88.62298
#> 4            88.62298
#> 5            88.62298
#> 6            88.62298
#> 7            88.62298
#> 8            88.62298
```

items that were significant before, now tested with weight_prec

``` r
params <- sim_parameters(mc_cores = 20, weight_function = "weight_prec")
weight_prec <- test_items_against_dimension(
  c("A129", "A144", "A164", "A99", "C35", "E17", "E2", "N31", "N96"),
  neo_pi_r_eugene,
  params
)
weight_prec %>% group_by(i) %>% slice(1) %>% select(i, p_aggregated)
#> # A tibble: 9 × 2
#> # Groups:   i [9]
#>   i     p_aggregated
#>   <chr>        <dbl>
#> 1 A129          0   
#> 2 A144          0   
#> 3 A164          0   
#> 4 A99           0   
#> 5 C35           0   
#> 6 E17           0   
#> 7 E2            0   
#> 8 N31           0.05
#> 9 N96           0
```
